$(document).ready(function() {
    $("button").click(function() {
        var title = $('#title').val();
        var question = $('#question').val();

        let record = {
            // "name": $('#ip').val(),
            // "pwd": $('#ip2').val()
            "title": title,
            "question": question
        }
        $.ajax({
            url: " http://localhost:3000/questions",
            type: "post",
            data: record,
            dataType: 'JSON',
            success: function() {

                $('form').submit();
            },
            error: function() {
                alert("Error.!!");
            }

        });

    });
});